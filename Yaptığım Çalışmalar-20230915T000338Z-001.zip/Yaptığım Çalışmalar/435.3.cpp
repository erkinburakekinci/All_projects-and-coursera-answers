#include <stdio.h>
#include <math.h>
#include <conio.h>
int main()
{
	int i,j;
	int a=0;
	int d=0;
	int l=0;
	int c;
	float b;
	float revm[10];
	float rsmu[10];
	float ryas[10];
	int evm[]={200,185,95,130,145,100,160,105,170,120};
	int smu[]={4,2,11,9,3,13,15,7,14,6};
	int yas[]={6,4,2,3,5,0,0,1,6,3};
	printf("\n\n evm \n");
	for (j=0 ; j<10 ;j++) 
	{
		
		c=evm[j]*evm[j];
		printf("%d\n\n",c);
		a=c+a;
			
	}
	printf("%d \n\n",a);
	
	b=sqrt(a);
	
	printf("%f \n\n",b);
	for (i=0 ; i<10 ;i++) 
	{
		revm[i]=evm[i]/b;
		printf("%f \n",revm[i]);
	}
	printf("\n\n smu \n");
	for (j=0 ; j<10 ;j++) 
	{
		
		c=smu[j]*smu[j];
		printf("%d\n\n",c);
		d=c+d;
			
	}
	printf("%d \n\n",d);
	
	b=sqrt(d);
	
	printf("%f \n\n",b);
	for (i=0 ; i<10 ;i++) 
	{
		rsmu[i]=smu[i]/b;
		printf("%f \n",rsmu[i]);
	}
	printf("\n\n yas \n");
	
	for (j=0 ; j<10 ;j++) 
	{
		
		c=yas[j]*yas[j];
		printf("%d\n\n",c);
		l=c+l;
			
	}
	printf("%d \n\n",l);
	
	b=sqrt(l);
	
	printf("%f \n\n",b);
	for (i=0 ; i<10 ;i++) 
	{
		ryas[i]=yas[i]/b;
		printf("%f \n",ryas[i]);
	}	
	
	printf("\n\n");
	float w1=0.35;
	float w2=0.45;
	float w3=0.2;	
	float vevm[10];
	float vsmu[10];
	float vyas[10];
	printf("\n\n evm \n");

	for(i=0;i<10;i++){
		vevm[i]=revm[i]*w1;
		printf("%f\n",vevm[i]);
		
	}
	
	printf("\n\n smu \n");

	for(i=0;i<10;i++){
		vsmu[i]=rsmu[i]*w2;
		printf("%f\n",vsmu[i]);
		
	}
	
	printf("\n\n yas \n");

	for(i=0;i<10;i++){
		vyas[i]=ryas[i]*w3;
		printf("%f\n",vyas[i]);
		
	}
	printf("\n\n");
	float si[10];
	float a1i=0.152;
	float a2i=0.224;
	float a3i=0.102;
	float sj[10];
	float a1j=0.072;
	float a2j=0.029;
	float a3j=0.000;
	float y;
	float u;
	float o;
	float p;	
	printf("s+=\n");
	for(i=0;i<10;i++){
		y=(vevm[i]-a1i)*(vevm[i]-a1i);
		u=(vsmu[i]-a2i)*(vsmu[i]-a2i);
		o=(vyas[i]-a3i)*(vyas[i]-a3i);
		p=y+u+o;
		p=sqrt(p);
		si[i]=p;
		printf("%f \n",si[i]);
	}
	printf("\n s-= \n");
	for(i=0;i<10;i++){
		y=(vevm[i]-a1j)*(vevm[i]-a1j);
		u=(vsmu[i]-a2j)*(vsmu[i]-a2j);
		o=(vyas[i]-a3j)*(vyas[i]-a3j);
		p=y+u+o;
		p=sqrt(p);
		sj[i]=p;
		printf("%f \n",sj[i]);
	}
	printf("\n g= \n\n");		
	float g[10];
	for(i=0;i<10;i++){
		g[i]=sj[i]/(si[i]+sj[i]);
		printf("\n %f ",g[i]);
	}
	
	
}
