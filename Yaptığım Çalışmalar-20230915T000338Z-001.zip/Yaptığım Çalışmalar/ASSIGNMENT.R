#Bu yazilanlarin bazilarini stackoverflow araciligiyle yazdim.
#5.soru
simulasyon_sayisi <- 1000

ust_sayilar <- 0

for (i in 1:simulasyon_sayisi) {
  
  sayi <- runif(1, min = 0, max = 1)
  
  
  if (sayi > 0.8) {
    ust_sayilar <- ust_sayilar + 1
  }
}

olasilik <- ust_sayilar / simulasyon_sayisi

print(olasilik)
#4.soru
#A şıkkı
toplam_top_sayisi <- 10

siyah_top_sayisi <- 4

cekilen_top_sayisi <- 5

olasilik <- dhyper(0:3, m = siyah_top_sayisi, n = toplam_top_sayisi - siyah_top_sayisi, k = cekilen_top_sayisi)
print(sum(olasilik))




#B şıkkı
# Toplam topların sayısı
toplam_top_sayisi <- 10

# Siyah topların sayısı
siyah_top_sayisi <- 4

# Çekilecek topların sayısı
cekilen_top_sayisi <- 5

# Siyah topların beklenen sayısını hesapla
beklenen_sayi <- cekilen_top_sayisi * (siyah_top_sayisi / toplam_top_sayisi)

# Sonucu ekrana yazdır
print(beklenen_sayi)



#C şıkkı 
toplam_top_sayisi <- 10

siyah_top_sayisi <- 4

cekilen_top_sayisi <- 5

beklenen_sayi <- cekilen_top_sayisi * (siyah_top_sayisi / toplam_top_sayisi)

siyah_kazanc <- 100

beyaz_kayip <- 50

beklenen_kazanc <- beklenen_sayi * siyah_kazanc + (cekilen_top_sayisi - beklenen_sayi) * beyaz_kayip
print(beklenen_kazanc)

#3.soru
matris <- matrix(0, nrow = 5, ncol = 5)
for (i in 1:5) {
  for (j in i:5) {
    matris[i, j] <- 20
  }
}
for (i in 2:5) {
  for (j in 1:(i-1)) {
    matris[i, j] <- 15
  }
}
for (i in 1:5) {
  matris[i, i] <- 10
}
print(matris)



#1.soru
#A
library(actuar)

theta <- 4

olasilik <- 1 - pexp(4, rate = theta)

print(paste("P(Y > 4):", olasilik))




#B
library(actuar)

theta <- 4

olasilik <- pexp(6, rate = theta)

print(paste("P(Y < 6):", olasilik))



#C
library(actuar)

theta <- 4

olasilik <- 0.95

a <- qexp(1 - olasilik, rate = theta)

print(paste("a:", a))





#D
library(actuar)

theta <- 4

olasilik <- 0.75

b <- qexp(olasilik, rate = theta)

print(paste("b:", b))





#E
library(actuar)

theta <- 4

olasilik <- dexp(4, rate = theta)

print(paste("P(Y = 4):", olasilik))

#2.soru
#A
library(actuar)
n <- 100000 
lambda <- 4  
p1_dayanma <- rexp(n, rate = lambda)
p2_dayanma <- rexp(n, rate = lambda)
p3_dayanma <- rexp(n, rate = lambda)
p4_dayanma <- rexp(n, rate = lambda)
toplam_dayanma <- 1 / (1/p1_dayanma + 1/p2_dayanma + 1/p3_dayanma + 1/p4_dayanma)
ortalama_dayanma <- mean(toplam_dayanma)
print(paste("Ortalama Dayanma Süresi:", ortalama_dayanma))


#B
library(actuar)
n <- 100000 
lambda <- 4 
p1_dayanma <- rexp(n, rate = lambda)
p2_dayanma <- rexp(n, rate = lambda)
p3_dayanma <- rexp(n, rate = lambda)
p4_dayanma <- rexp(n, rate = lambda)

en_az_2_yil_olasilik <- mean(p1_dayanma + p2_dayanma + p3_dayanma + p4_dayanma >= 2)

print(paste("En az 2 yıl dayanma olasılığı:", en_az_2_yil_olasilik))


#C
library(actuar)
library(ggplot2)
n <- 100000  
lambda <- 4  

p1_dayanma <- rexp(n, rate = lambda)
p2_dayanma <- rexp(n, rate = lambda)
p3_dayanma <- rexp(n, rate = lambda)
p4_dayanma <- rexp(n, rate = lambda)

toplam_dayanma <- p1_dayanma + p2_dayanma + p3_dayanma + p4_dayanma

ggplot(data.frame(toplam_dayanma), aes(x = toplam_dayanma)) +
  geom_histogram(binwidth = 0.1, fill = "lightblue", color = "black") +
  labs(title = "Devrenin Ortalama Dayanma Süresi Histogramı",
       x = "Ortalama Dayanma Süresi",
       y = "Frekans")